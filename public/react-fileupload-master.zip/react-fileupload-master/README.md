# [React file upload](https://reactgo.com/react-file-upload/)

[![React file upload](https://user-images.githubusercontent.com/33011208/71660657-c5b8d300-2d71-11ea-8f7d-1e00f6406b2e.png)](https://reactgo.com/react-file-upload/)

## Setting up backend server

you can setup backend api by cloning [express-fileupload](https://github.com/saigowthamr/express-fileupload) project.

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.<br />
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.<br />
You will also see any lint errors in the console.
