#pragma once

struct Vec2
{
    float x{};
    float y{};

    Vec2(){}

    Vec2(float x, float y)
    {
        this->x = x;
        this->y = y;
    }
};
